export type ShipmentType = 'delivery' | 'pickup';

export interface Stop {
  address: string;
  lat: number;
  lng: number;
  order: number;
  load: number;
  type: 'depot' | ShipmentType;
}

export interface Route {
  vehicleId: number;
  vehiclePlate: string;
  stops: Stop[];
  totalLoad: number; // Represents the initial load of *delivery* items
  vehicleCapacity: number;
}

export interface OptimizedRoutesResponse {
  routes: Route[];
}

export interface Vehicle {
    id: string;
    plate: string;
    capacity: number;
}

export interface SavedAddress {
    id: string;
    address: string;
    isDepot?: boolean;
}

export interface Shipment {
    id: string;
    address: string;
    load: number;
    type: ShipmentType;
}