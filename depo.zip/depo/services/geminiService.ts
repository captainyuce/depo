import { GoogleGenAI } from "@google/genai";
import type { OptimizedRoutesResponse, Shipment, Vehicle } from '../types';

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

function buildPrompt(shipments: Shipment[], vehicles: Vehicle[]): string {
  const depot = shipments[0];
  const deliveries = shipments.slice(1).filter(s => s.type === 'delivery');
  const pickups = shipments.slice(1).filter(s => s.type === 'pickup');

  const vehicleDetails = vehicles.map((v, i) => 
    `- Vehicle ID: ${i + 1}, Plate: "${v.plate}", Capacity: ${v.capacity}`
  ).join('\n');

  const deliveryDetails = deliveries.length > 0
    ? deliveries.map(d => `- Address: "${d.address}", Load: ${d.load}`).join('\n')
    : "Yok";

  const pickupDetails = pickups.length > 0
    ? pickups.map(p => `- Address: "${p.address}", Load: ${p.load}`).join('\n')
    : "Yok";

  return `
You are an expert logistics coordinator AI specializing in solving the Vehicle Routing Problem with Pickups and Deliveries (VRPPD). Your task is to determine the most efficient routes for a fleet of vehicles to perform deliveries and pickups, starting from and returning to a central depot.

**Problem Details:**

- **Vehicles (with their capacities):**
${vehicleDetails}

- **Central Depot (Start/End Point):**
  - Address: "${depot.address}"

- **Task Breakdown:**
  1.  **Deliveries (Goods loaded at Depot):**
${deliveryDetails}
  2.  **Pickups (Goods collected and returned to Depot):**
${pickupDetails}


**Your Instructions:**

1.  **Geocode Addresses:** For each address (depot, deliveries, and pickups), provide its estimated latitude and longitude.
2.  **Assign Routes:** Assign each destination (both delivery and pickup) to one of the available vehicles. Each destination must be visited exactly once.
3.  **CRITICAL CAPACITY CONSTRAINT:** The total weight of all items inside a vehicle **at any point in its journey** must not exceed the vehicle's capacity.
    - A vehicle's initial load from the depot is the sum of all 'delivery' loads assigned to it.
    - At each 'pickup' stop, the vehicle's current load increases. This new total load must not exceed the vehicle capacity.
4.  **Optimize Stop Order:** For each vehicle, determine the optimal sequence of stops to minimize travel time/distance, considering the capacity constraint at every step. Each vehicle's route must start at the depot and end back at the depot.
5.  **Balance Workload:** Distribute the destinations among the vehicles as evenly as possible, respecting all constraints.
6.  **Format Output:** Respond ONLY with a valid JSON object. Do not include any other text, explanations, or markdown fences. The JSON object must strictly follow this schema:

    \`\`\`json
    {
      "routes": [
        {
          "vehicleId": <number>,
          "vehiclePlate": "<string>",
          "vehicleCapacity": <number>,
          "totalLoad": <number>,
          "stops": [
            { "address": "<string>", "lat": <number>, "lng": <number>, "order": <number>, "load": <number>, "type": "depot" | "delivery" | "pickup" },
            ...
          ]
        }
      ]
    }
    \`\`\`

**JSON Schema Rules:**
- \`routes\`: An array of route objects. Can be empty if no solution is found.
- \`vehicleId\`: The identifier number for the vehicle (e.g., 1, 2, 3...).
- \`vehiclePlate\`: The license plate of the assigned vehicle.
- \`vehicleCapacity\`: The maximum capacity of the vehicle.
- \`totalLoad\`: The sum of the 'load' of all **delivery** stops assigned to this vehicle (the initial load from the depot).
- \`stops\`: An array for the vehicle's path.
  - The first and last stops in the array must be the depot, with \`type: "depot"\` and \`load: 0\`.
  - \`type\`: Must be one of "depot", "delivery", or "pickup".
  - \`load\`: For "delivery" and "pickup" stops, this is the weight of the items.
  - \`order\`: A zero-indexed integer for the stop sequence.

Now, generate the JSON response for the given problem.
`;
}


export const optimizeRoutes = async (shipments: Shipment[], vehicles: Vehicle[]): Promise<OptimizedRoutesResponse> => {
  const prompt = buildPrompt(shipments, vehicles);

  try {
    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-04-17",
        contents: prompt,
        config: {
            responseMimeType: "application/json",
            temperature: 0.2,
        },
    });

    let jsonStr = response.text.trim();
    
    const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
    const match = jsonStr.match(fenceRegex);
    if (match && match[2]) {
        jsonStr = match[2].trim();
    }

    const parsedData: OptimizedRoutesResponse = JSON.parse(jsonStr);

    if (!parsedData.routes || !Array.isArray(parsedData.routes)) {
        throw new Error("Geçersiz yanıt formatı: 'routes' dizisi bulunamadı.");
    }
    
    return parsedData;

  } catch (error) {
    console.error("Gemini API yanıtı alınırken veya işlenirken hata oluştu:", error);
    if (error instanceof Error) {
        throw new Error(`Rotalar optimize edilemedi: ${error.message}`);
    }
    throw new Error("Rotalar optimize edilirken bilinmeyen bir hata oluştu.");
  }
};