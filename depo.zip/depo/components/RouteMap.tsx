import React, { useEffect, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L, { LatLngBoundsExpression, LatLngExpression } from 'leaflet';
import 'leaflet-routing-machine';
import type { Route } from '../types';

// Each object contains an 'outbound' (lighter) and 'inbound' (darker) color for a single vehicle's route.
const ROUTE_COLOR_PAIRS = [
  { outbound: '#60a5fa', inbound: '#2563eb' }, // Blue
  { outbound: '#4ade80', inbound: '#16a34a' }, // Green
  { outbound: '#f87171', inbound: '#dc2626' }, // Red
  { outbound: '#facc15', inbound: '#ca8a04' }, // Yellow
  { outbound: '#a78bfa', inbound: '#7c3aed' }, // Violet
  { outbound: '#f472b6', inbound: '#db2777' }, // Pink
  { outbound: '#fb923c', inbound: '#ea580c' }, // Orange
  { outbound: '#22d3ee', inbound: '#0891b2' }  // Cyan
];


const RouteLine: React.FC<{ waypoints: LatLngExpression[], color: string }> = ({ waypoints, color }) => {
  const map = useMap();

  useEffect(() => {
    if (!map || waypoints.length < 2) return;

    const routingControl = L.Routing.control({
      waypoints: waypoints.map(wp => L.latLng(wp as L.LatLngTuple)),
      routeWhileDragging: false,
      addWaypoints: false,
      show: false, // Hide the turn-by-turn instructions panel
      createMarker: () => null, // We already have our own markers
      lineOptions: {
        styles: [{ color, weight: 5, opacity: 0.8 }],
        extendToWaypoints: true,
        missingRouteTolerance: 100
      }
    }).addTo(map);

    return () => {
      if (map && routingControl) {
        map.removeControl(routingControl);
      }
    };
  }, [map, waypoints, color]);

  return null;
};


interface MapUpdaterProps {
  bounds: LatLngBoundsExpression;
}

const MapUpdater: React.FC<MapUpdaterProps> = ({ bounds }) => {
  const map = useMap();
  useEffect(() => {
    if (bounds && Array.isArray(bounds) && bounds.length > 0) {
      map.fitBounds(bounds, { padding: [50, 50] });
    }
  }, [bounds, map]);
  return null;
};

interface RouteMapProps {
  routes: Route[] | null;
}

const RouteMap: React.FC<RouteMapProps> = ({ routes }) => {
  const defaultPosition: LatLngExpression = [39.925533, 32.866287]; // Default to Ankara

  const bounds = useMemo((): LatLngBoundsExpression | null => {
    if (!routes || routes.length === 0) return null;
    const allStops = routes.flatMap(route => route.stops);
    if (allStops.length === 0) return null;

    const latLngs: LatLngExpression[] = allStops.map(stop => [stop.lat, stop.lng]);
    return latLngs as LatLngBoundsExpression;
  }, [routes]);

  const getStopLabel = (stop: Route['stops'][0]): string => {
    switch(stop.type) {
      case 'depot':
        return 'Depo';
      case 'delivery':
        return `Teslimat Durağı #${stop.order}`;
      case 'pickup':
        return `Toplama Durağı #${stop.order}`;
      default:
        return `Durak #${stop.order}`;
    }
  }

  return (
    <MapContainer center={defaultPosition} zoom={6} scrollWheelZoom={true} className="h-full w-full z-0">
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {routes && routes.map((route, routeIndex) => {
        if (route.stops.length < 2) {
          return null; // Not enough stops to form a route
        }

        // The main "outbound" journey from the depot to all customer stops
        const outboundStops = route.stops.slice(0, -1);
        const outboundWaypoints: LatLngExpression[] = outboundStops.map(stop => [stop.lat, stop.lng]);

        // The "inbound" return journey from the last customer stop back to the depot
        const inboundStops = route.stops.slice(-2);
        const inboundWaypoints: LatLngExpression[] = inboundStops.map(stop => [stop.lat, stop.lng]);
        
        const colorPair = ROUTE_COLOR_PAIRS[routeIndex % ROUTE_COLOR_PAIRS.length];
        
        return (
          <React.Fragment key={route.vehicleId}>
            {/* Outbound path with a unique lighter color */}
            {outboundWaypoints.length >= 2 && (
              <RouteLine waypoints={outboundWaypoints} color={colorPair.outbound} />
            )}
            
            {/* Inbound path with a unique darker color */}
            {inboundWaypoints.length >= 2 && (
              <RouteLine waypoints={inboundWaypoints} color={colorPair.inbound} />
            )}

            {/* Markers for all stops */}
            {route.stops.map((stop, stopIndex) => (
              <Marker key={`${route.vehicleId}-${stopIndex}`} position={[stop.lat, stop.lng]}>
                <Popup>
                  <div className="font-sans">
                    <p className="font-bold text-base">
                      {getStopLabel(stop)}
                    </p>
                    <p className="text-sm">{stop.address}</p>
                    <p className="text-xs text-gray-500">Araç: {route.vehiclePlate}</p>
                    {stop.load > 0 && <p className="text-xs text-gray-500">Yük: {stop.load} kg</p>}
                  </div>
                </Popup>
              </Marker>
            ))}
          </React.Fragment>
        );
      })}
      {bounds && <MapUpdater bounds={bounds} />}
    </MapContainer>
  );
};

export default RouteMap;