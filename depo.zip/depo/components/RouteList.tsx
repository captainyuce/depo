import React from 'react';
import { Route, Stop } from '../types';
import { TruckIcon, PinIcon } from './icons';

interface RouteListProps {
  routes: Route[] | null;
}

const getStopDescription = (stop: Stop, isLast: boolean): string => {
    if (stop.type === 'depot') {
        return stop.order === 0 ? 'Depodan Başla' : 'Depoya Dön';
    }
    const loadText = stop.load > 0 ? ` (${stop.load} kg)` : '';
    if (stop.type === 'delivery') {
        return `Teslimat Durağı ${stop.order}${loadText}`;
    }
    if (stop.type === 'pickup') {
        return `Toplama Durağı ${stop.order}${loadText}`;
    }
    return '';
}

const RouteList: React.FC<RouteListProps> = ({ routes }) => {
  if (!routes || routes.length === 0) {
    return null;
  }

  return (
    <div className="bg-white p-4 shadow-inner border-t border-gray-200 overflow-y-auto max-h-64 md:max-h-56 lg:max-h-72">
      <h3 className="font-bold text-lg mb-3 text-gray-800">Optimize Edilmiş Rotalar</h3>
      <div className="space-y-4">
        {routes.map((route, index) => (
          <div key={route.vehicleId} className="p-3 bg-gray-50 rounded-lg border border-gray-200">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center">
                <TruckIcon color={['#3b82f6', '#16a34a', '#ef4444', '#eab308', '#8b5cf6'][index % 5]} />
                <h4 className="font-semibold ml-2 text-gray-700">Araç: {route.vehiclePlate}</h4>
              </div>
              <div className="text-sm font-medium text-gray-600">
                Yük: {route.totalLoad} / {route.vehicleCapacity} kg (Başlangıç)
              </div>
            </div>
            <ol className="relative border-l border-gray-300 ml-2">
              {route.stops.map((stop, stopIndex) => (
                <li key={stopIndex} className="mb-4 ml-6">
                  <span className="absolute flex items-center justify-center w-6 h-6 bg-blue-100 rounded-full -left-3 ring-8 ring-white">
                    <PinIcon isDepot={stop.type === 'depot'} />
                  </span>
                  <div className="ml-2">
                    <h5 className="font-medium text-gray-900">{stop.address}</h5>
                    <p className="text-sm text-gray-500">
                      {getStopDescription(stop, stopIndex === route.stops.length - 1)}
                    </p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        ))}
      </div>
    </div>
  );
};

export default RouteList;