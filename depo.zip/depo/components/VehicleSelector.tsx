

import React from 'react';
import type { Vehicle } from '../types';
import { TruckIcon, PlusIcon, TrashIcon } from './icons';

interface VehicleManagerProps {
  vehicles: Vehicle[];
  setVehicles: (vehicles: Vehicle[]) => void;
}

const VehicleSelector: React.FC<VehicleManagerProps> = ({ vehicles, setVehicles }) => {
  
  const handleVehicleChange = (id: string, field: 'plate' | 'capacity', value: string | number) => {
    const newVehicles = vehicles.map(v => {
        if (v.id === id) {
            return { ...v, [field]: value };
        }
        return v;
    });
    setVehicles(newVehicles);
  };

  const addVehicle = () => {
    const newPlateNumber = vehicles.length + 1;
    setVehicles([...vehicles, { id: crypto.randomUUID(), plate: `ARAC-${newPlateNumber}`, capacity: 1000 }]);
  };

  const removeVehicle = (id: string) => {
    setVehicles(vehicles.filter(v => v.id !== id));
  };

  return (
    <div>
      <h3 className="text-md font-semibold text-gray-700 mb-3">
        Araç Yönetimi
      </h3>
      <div className="space-y-3">
        {vehicles.length === 0 && (
            <p className="text-sm text-gray-500">Henüz araç eklenmedi. Planlama için lütfen araç ekleyin.</p>
        )}
        {vehicles.map((vehicle) => (
            <div key={vehicle.id} className="flex items-center space-x-2 p-2 border border-gray-200 rounded-lg">
                <TruckIcon />
                <input
                    type="text"
                    value={vehicle.plate}
                    onChange={(e) => handleVehicleChange(vehicle.id, 'plate', e.target.value)}
                    placeholder="Plaka"
                    className="w-1/2 p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 transition"
                />
                <input
                    type="number"
                    value={vehicle.capacity}
                    onChange={(e) => handleVehicleChange(vehicle.id, 'capacity', parseInt(e.target.value, 10) || 0)}
                    placeholder="Kapasite"
                    min="0"
                    className="w-1/2 p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500 transition"
                />
                 <button
                    onClick={() => removeVehicle(vehicle.id)}
                    className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-100 rounded-full transition-colors"
                    aria-label="Aracı kaldır"
                >
                    <TrashIcon />
                </button>
            </div>
        ))}
      </div>
       <button
        onClick={addVehicle}
        className="mt-4 flex items-center space-x-2 text-sm font-medium text-blue-600 hover:text-blue-800 transition-colors"
      >
        <PlusIcon />
        <span>Araç Ekle</span>
      </button>
    </div>
  );
};

export default VehicleSelector;
