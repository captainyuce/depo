import React from 'react';
import type { Shipment, ShipmentType, SavedAddress } from '../types';
import { BoxIcon, ArrowDownTrayIcon, ArrowUpTrayIcon, HomeIcon } from './icons';

interface PlannerProps {
  savedAddresses: SavedAddress[];
  shipments: Shipment[];
  setShipments: (shipments: Shipment[]) => void;
}

const AddressInput: React.FC<PlannerProps> = ({ savedAddresses, shipments, setShipments }) => {
  // Find the depot from saved addresses
  const depot = savedAddresses.find(addr => addr.isDepot);

  const handleToggleStop = (address: SavedAddress) => {
    const isSelected = shipments.some(s => s.address === address.address);

    if (isSelected) {
      setShipments(shipments.filter(s => s.address !== address.address));
    } else {
      const newStop: Shipment = { id: crypto.randomUUID(), address: address.address, load: 100, type: 'delivery' };
      setShipments([...shipments, newStop]);
    }
  };

  const handleShipmentChange = (id: string, field: 'load' | 'type', value: number | ShipmentType) => {
    setShipments(shipments.map(s => s.id === id ? { ...s, [field]: value } : s));
  };

  // Stops available for selection are saved addresses that are not the depot
  const availableStops = savedAddresses.filter(addr => !addr.isDepot);

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Sevkiyat Planı</h3>
        {!depot ? (
          <div className="p-4 text-center bg-yellow-50 border border-yellow-300 rounded-lg">
            <p className="text-sm text-yellow-800">Başlamak için lütfen 'Konumlar' sekmesinden bir ana depo belirleyin.</p>
          </div>
        ) : (
          <>
            {/* Display Fixed Depot */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-600 mb-1">Depo / Başlangıç Noktası</label>
              <div className="flex items-center p-3 border border-gray-200 rounded-md bg-gray-100">
                  <HomeIcon />
                  <span className="ml-3 font-semibold text-gray-700">{depot.address}</span>
              </div>
            </div>

            {/* Durak Seçimi */}
            {availableStops.length > 0 ? (
              <div className="mb-4">
                <label className="block text-sm font-medium text-gray-600 mb-2">Durakları Seçin</label>
                <div className="space-y-2 max-h-48 overflow-y-auto pr-2 border rounded-md p-2 bg-gray-50">
                  {availableStops.map(addr => {
                    const isSelected = shipments.some(s => s.address === addr.address);
                    return (
                      <label key={addr.id} htmlFor={`stop-${addr.id}`} className={`flex items-center p-2 rounded-md cursor-pointer transition-colors ${isSelected ? 'bg-blue-100 border-blue-300 ring-1 ring-blue-400' : 'bg-white hover:bg-gray-100 border-transparent'} border`}>
                        <input
                          type="checkbox"
                          id={`stop-${addr.id}`}
                          checked={isSelected}
                          onChange={() => handleToggleStop(addr)}
                          className="h-4 w-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                        />
                        <span className="ml-3 text-sm text-gray-700">{addr.address}</span>
                      </label>
                    );
                  })}
                </div>
              </div>
            ) : (
                <div className="p-3 text-center bg-gray-50 border rounded-lg">
                    <p className="text-sm text-gray-600">Eklenecek başka durak bulunmuyor. Yeni konumları 'Konumlar' sekmesinden ekleyebilirsiniz.</p>
                </div>
            )}
            
            {/* Planlanmış Duraklar Detayları */}
            {shipments.length > 0 && (
              <div>
                <h4 className="text-sm font-medium text-gray-600 mb-2 mt-4">Planlanmış Durak Detayları</h4>
                <div className="space-y-3">
                  {shipments.map((shipment, index) => (
                    <div key={shipment.id} className="p-3 border border-gray-200 rounded-lg bg-white">
                      <div className="flex items-center space-x-2">
                        <span className="flex items-center justify-center h-6 w-6 rounded-full text-xs font-semibold bg-gray-300 text-gray-700">{index + 1}</span>
                        <p className="flex-grow p-2 text-sm font-medium">{shipment.address}</p>
                      </div>
                      <div className="flex items-center space-x-3 mt-3 pl-8">
                        <div className="flex items-center space-x-2 w-1/2">
                          <BoxIcon />
                          <input type="number" value={shipment.load} onChange={(e) => handleShipmentChange(shipment.id, 'load', parseInt(e.target.value, 10) || 0)} className="w-full p-2 border border-gray-300 rounded-md" min="0" />
                          <span className="text-sm text-gray-500">kg</span>
                        </div>
                        <div className="flex w-1/2" role="group">
                          <button type="button" onClick={() => handleShipmentChange(shipment.id, 'type', 'delivery')} className={`w-full inline-flex items-center justify-center px-2 py-2 text-sm font-medium transition-colors border rounded-l-lg ${shipment.type === 'delivery' ? 'bg-blue-600 text-white border-blue-600 z-10' : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'}`}>
                            <ArrowDownTrayIcon />
                          </button>
                          <button type="button" onClick={() => handleShipmentChange(shipment.id, 'type', 'pickup')} className={`w-full inline-flex items-center justify-center px-2 py-2 text-sm font-medium transition-colors border-t border-b border-r rounded-r-lg ${shipment.type === 'pickup' ? 'bg-green-600 text-white border-green-600 z-10' : 'bg-white text-gray-700 border-gray-300 hover:bg-gray-50'}`}>
                            <ArrowUpTrayIcon />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
};

export default AddressInput;