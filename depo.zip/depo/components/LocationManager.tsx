import React, { useState } from 'react';
import type { SavedAddress } from '../types';
import { PlusIcon, TrashIcon, HomeIcon } from './icons';

interface LocationManagerProps {
  savedAddresses: SavedAddress[];
  setSavedAddresses: (addresses: SavedAddress[]) => void;
}

const LocationManager: React.FC<LocationManagerProps> = ({ savedAddresses, setSavedAddresses }) => {
  const [newAddress, setNewAddress] = useState('');
  
  const handleAddSavedAddress = () => {
    if (newAddress.trim()) {
      const isFirstAddress = savedAddresses.length === 0;
      setSavedAddresses([...savedAddresses, { id: crypto.randomUUID(), address: newAddress.trim(), isDepot: isFirstAddress }]);
      setNewAddress('');
    }
  };

  const handleRemoveSavedAddress = (id: string) => {
    const addressToRemove = savedAddresses.find(a => a.id === id);
    if (!addressToRemove) return;

    if (addressToRemove.isDepot) {
        alert("Ana depo silinemez. Lütfen önce başka bir konumu ana depo olarak atayın.");
        return;
    }

    if (window.confirm(`'${addressToRemove.address}' konumunu silmek istediğinizden emin misiniz?`)) {
      setSavedAddresses(savedAddresses.filter(a => a.id !== id));
    }
  };

  const handleSetDepot = (id: string) => {
    const newAddresses = savedAddresses.map(addr => ({
      ...addr,
      isDepot: addr.id === id
    }));
    setSavedAddresses(newAddresses);
  };

  return (
    <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 mb-4">Kayıtlı Konumlar</h3>
        <div className="space-y-2">
            {savedAddresses.length === 0 && (
                <p className="text-sm text-gray-500">Henüz kayıtlı konum yok. Lütfen sevkiyat yapılacak adresleri ekleyin.</p>
            )}
            {savedAddresses.map(addr => (
                <div key={addr.id} className={`flex items-center space-x-2 text-sm p-2 border rounded-lg transition-colors ${addr.isDepot ? 'bg-blue-100 border-blue-300' : 'bg-gray-50 border-gray-200'}`}>
                    <button 
                      onClick={() => handleSetDepot(addr.id)} 
                      className={`p-2 rounded-full transition-colors ${addr.isDepot ? 'text-blue-600' : 'text-gray-400 hover:text-blue-500 hover:bg-blue-100'}`} 
                      aria-label="Ana depo olarak ayarla"
                      title="Ana depo olarak ayarla"
                    >
                      <HomeIcon />
                    </button>
                    <input type="text" value={addr.address} readOnly className="flex-grow p-1 bg-transparent border-none rounded-md focus:outline-none" />
                    <button 
                      onClick={() => handleRemoveSavedAddress(addr.id)} 
                      className={`p-2 rounded-full transition-colors ${addr.isDepot ? 'text-gray-300 cursor-not-allowed' : 'text-gray-400 hover:text-red-500 hover:bg-red-100'}`} 
                      aria-label="Konumu kaldır"
                      disabled={addr.isDepot}
                    >
                      <TrashIcon/>
                    </button>
                </div>
            ))}
        </div>
        <div className="flex space-x-2 pt-2">
            <input
                type="text"
                value={newAddress}
                onChange={(e) => setNewAddress(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleAddSavedAddress()}
                placeholder="Yeni konum adresi ekle"
                className="flex-grow p-2 border border-gray-300 rounded-md shadow-sm focus:ring-blue-500 focus:border-blue-500"
            />
            <button onClick={handleAddSavedAddress} disabled={!newAddress.trim()} className="p-2 bg-blue-600 text-white hover:bg-blue-700 rounded-md shadow-sm disabled:bg-blue-300"><PlusIcon /></button>
        </div>
    </div>
  );
};

export default LocationManager;